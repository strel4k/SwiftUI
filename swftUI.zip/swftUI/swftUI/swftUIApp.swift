//
//  swftUIApp.swift
//  swftUI
//
//  Created by Alexander on 29.10.2022.
//

import SwiftUI

@main
struct swftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

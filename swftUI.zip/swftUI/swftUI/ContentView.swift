//
//  ContentView.swift
//  swftUI
//
//  Created by Alexander on 29.10.2022.
//

import SwiftUI

struct ContentView: View {
    
    @State private var counter: Float = 0
    @State private var isAlertPresented: Bool = false
    @State private var text: String = ""
    
    var body: some View {
        NavigationView {
            
            VStack {
                
                NavigationLink(destination: LoginView()) {
                    Text("On VK login page")
                }
                .padding()
                
                Text("Hello, World!")
                    .modifier(TitleModifier())
                    .padding(.bottom, 32)
                Text("Blah-Blah")
                    .modifier(TextModifier())
                
                Image(systemName: "globe")
                    .padding(.all, 20)
                    .imageScale(.large)
                    .foregroundColor(.accentColor)
                
                VStack {
                    Text("\(counter)")
                    Slider(
                        value: $counter,
                        in: 0...10,
                        onEditingChanged: { _ in })
                    
                    Button("Tap") { isAlertPresented = true }
                }
                Spacer()
            }
            .alert("QQ",
                   isPresented: $isAlertPresented,
                   actions: {})
            .searchable(text: $text)
            .frame(
                maxWidth: .infinity,
                alignment: .leading
            )
            .padding(.leading, 16)
            .padding(.trailing, 16)
            .padding(.top, 60)
        }
        .debug()
    }
}

struct TitleModifier: ViewModifier {
    
    func body(content: Content) -> some View {
        content
            .font(.largeTitle.bold())
            .foregroundColor(Color.black)
            .padding()
            .background(Color.purple)
            .cornerRadius(5)
    }
}

struct TextModifier: ViewModifier {
    
    func body(content: Content) -> some View {
        content
            .font(.subheadline.bold())
            .foregroundColor(Color.white)
            .padding()
            .background(Color.green)
            .cornerRadius(16)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

extension View {
    func debug() -> Self {
        print("Example of view structure: \(Mirror(reflecting: self).subjectType)")
        return self
    }
}
